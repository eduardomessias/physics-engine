let yellowBall,
    blueBall;

function setup() {
  createCanvas(400, 400);

  setupYellowBall();
  setupBlueBall();
}

function draw() {
  background(0);

  let attraction = blueBall.attract(yellowBall);
  yellowBall.applyForce(attraction);
  
  drawYellowBall();
  drawBlueBall();  
}

function setupYellowBall() {
  yellowBall = new Ellipse();
  yellowBall.color = "#ffeaa7";
  yellowBall.mass = 1;
  yellowBall.location.x = width / 2 - 100;
  yellowBall.location.y = 100;
  yellowBall.velocity.x = 0.5;
}

function setupBlueBall() {
  blueBall = new Ellipse();
  blueBall.color = "#74b9ff";
  blueBall.mass = 2;
  blueBall.radius.mult(2);
  blueBall.location.x = width / 2;
  blueBall.location.y = height / 2;  
  blueBall.gravity = 1;
}

function drawYellowBall() {
  yellowBall.display();
  yellowBall.applyPhysics();
}

function drawBlueBall() {
  blueBall.display();
  blueBall.applyPhysics();    
}